package com.jwt_security_project.model;

public enum Role {
    USER,
    ADMIN
}
